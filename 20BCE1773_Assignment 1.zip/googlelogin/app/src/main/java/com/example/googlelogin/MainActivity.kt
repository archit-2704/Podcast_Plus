package com.example.googlelogin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.googlelogin.ui.theme.GoogleloginTheme
//Archit Agarwal 20BCE1773
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GoogleloginTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Login()
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Login() {
    Column(modifier = Modifier.padding(all = 20.dp), verticalArrangement = Arrangement.Center) {
        Image(
            painterResource(id = R.drawable.google),
            contentDescription = ""
        )
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = "Create Your Google Account",
            style = TextStyle(fontSize = 18.sp, fontFamily = FontFamily.Serif)
        )
        var a by remember {
            mutableStateOf(TextFieldValue())
        }
        var b by remember {
            mutableStateOf(TextFieldValue())
        }
        var c by remember {
            mutableStateOf(TextFieldValue())
        }

        Column(
            modifier = Modifier.padding(all = 20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TextField(
                value = a,
                onValueChange = { a = it },
                placeholder = { Text(text = "First Name") })
            Spacer(modifier = Modifier.height(10.dp))
            TextField(
                value = b,
                onValueChange = { b = it },
                placeholder = { Text(text = "Last Name") })
        }
        Column(
            modifier = Modifier.padding(all = 20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TextField(
                value = c,
                onValueChange = { c = it },
                placeholder = { Text(text = "Username@gmail.com") })

        }
        Text(
            text = "Use my current email address instead", style = TextStyle(fontSize = 12.sp,
                fontFamily = FontFamily.Serif, color = Color.Blue,), modifier = Modifier.padding(start=5.dp)
        )
            var e by remember {
                mutableStateOf(TextFieldValue())
            }
        var password by rememberSaveable { mutableStateOf("") }
        var passwordVisible by rememberSaveable { mutableStateOf(false) }
        Column(modifier = Modifier.padding(all = 20.dp)) {
        TextField(
        value = password,
        onValueChange = { password = it },
        label = { Text("Password") },
        singleLine = true,
        placeholder = { Text("Password") },
        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            val image = if (passwordVisible)
                Icons.Filled.Visibility
            else Icons.Filled.VisibilityOff

            // Please provide localized description for accessibility services
            val description = if (passwordVisible) "Hide password" else "Show password"

            IconButton(onClick = {passwordVisible = !passwordVisible}){
                Icon(imageVector  = image , description)
                }
            }
        )
    }
        Column(modifier = Modifier.padding(all = 20.dp)) {
            TextField(
                value = e,
                onValueChange = { e = it },
                placeholder = { Text(text = "Confirm") })
        }
        Row(
            modifier = Modifier.padding(all = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Button(onClick = {}, colors = ButtonDefaults.buttonColors(Color.White)) {
                Text(text = "Sign in instead", color = Color.Blue)
            }

            Button(onClick = {}, colors = ButtonDefaults.buttonColors(Color.Blue), modifier = Modifier.padding(start = 20.dp)) {
                Text(text = "Next", color = Color.White)
            }
        }
    }
}


