package com.example.vit_20bce1773_no3

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VideoPlayerApp: Application()